<?php
$str = "0";
$url = "./tmp_bakeryyurakucho".$str.".json";

while (file_exists($url)) {
$url = "./tmp_bakeryyurakucho".$str.".json";
	
$json = file_get_contents($url);
$json = mb_convert_encoding($json, 'UTF8', 'ASCII,JIS,UTF-8,EUC-JP,SJIS-WIN');
$arr = json_decode($json,true);
//$str = $str + 1;

if ($arr === NULL) {
	echo "no_data";
	return;
}else{
        $json_count = count($arr["results"]);
        $map_geo_loc_lat　= array();
        $map_geo_loc_lng　= array();
        $map_icon = array();
        $map_id = array();
        $map_name = array();
        $map_open = array();
        $map_photo_height = array();
        $map_photo_width = array();
        $map_place_id = array();
        $map_plus_comp_code = array();
        $map_plus_glob_code = array();
        $map_rating = array();
        $map_ref = array();
        $map_scope = array();
        $map_user_rat_total = array();
        $map_vicinity = array();

	//for($i=$json_count-1;$i>=0;$i--){
	for($i=19;$i>=0;$i--){

		$map_geo_loc_lat[] = $arr["results"][$i]["geometry"]["location"]["lat"];
		$map_geo_loc_lng[] = $arr["results"][$i]["geometry"]["location"]["lng"];
		$map_icon[] = $arr["results"][$i]["icon"];
		$map_id[] = $arr["results"][$i]["id"];
		$map_name[] = $arr["results"][$i]["name"];
		$map_open[] = $arr["results"][$i]["opening_hours"]["open_now"];
		$map_photo_height[] = $arr["results"][$i]["photos"][0]["height"];
		$map_photo_width[] = $arr["results"][$i]["photos"][0]["width"];
		$map_place_id[] = $arr["results"][$i]["place_id"];
		$map_plus_comp_code[] = $arr["results"][$i]["plus_code"]["compound_code"];
		$map_plus_glob_code[] = $arr["results"][$i]["plus_code"]["global_code"];
		$map_rating[] = $arr["results"][$i]["rating"];
		$map_ref[] = $arr["results"][$i]["reference"];
		$map_scope[] = $arr["results"][$i]["scope"];
		$map_user_rat_total[] = $arr["results"][$i]["user_ratings_total"];
		$map_vicinity[] = $arr["results"][$i]["vicinity"];

		if (isset($map_geo_loc_lat[$i])){
		if (isset($map_geo_loc_lng[$i])){
		if (isset($map_icon[$i])){
		if (isset($map_id[$i])){
		if (isset($map_name[$i])){
		if (isset($map_open[$i])){
		if (isset($map_photo_height[$i])){
		if (isset($map_photo_width[$i])){
		if (isset($map_place_id[$i])){
		if (isset($map_plus_comp_code[$i])){
		if (isset($map_plus_glob_code[$i])){
		if (isset($map_rating[$i])){
		if (isset($map_ref[$i])){
		if (isset($map_scope[$i])){
		if (isset($map_user_rat_total[$i])){
		if (isset($map_vicinity[$i])){

	try {
	// DSN指定
	$dsn = sprintf("mysql:host=%s;dbname=%s", 'localhost', 'google_map_data');
	
	// PDOインスタンス化
	$pdo = new PDO($dsn, 'google-map-data', 'XXXXXXXXXX');

	$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

		$stmt = $pdo->prepare('INSERT INTO all_data SET geo_loc_lat = ?, geo_loc_lng = ?, icon = ?, map_id = ?, name = ?, open = ?, photo_height = ?, photo_width = ?, place_id = ?, plus_comp_code = ?, plus_glob_code = ?, rating = ?, ref = ?, scope = ?, user_rat_total = ?, vicinity = ? ON DUPLICATE KEY UPDATE map_id = VALUES (map_id)');
		//$stmt = $pdo->prepare("INSERT INTO all_data (map_id, name) values (:map_id,:name)");

		$stmt->bindValue(1, $map_geo_loc_lat[$i]);
		$stmt->bindValue(2, $map_geo_loc_lng[$i]);
		$stmt->bindValue(3, $map_icon[$i]);
		$stmt->bindValue(4, $map_id[$i]);
		$stmt->bindValue(5, $map_name[$i]);
		$stmt->bindValue(6, $map_open[$i]);
		$stmt->bindValue(7, $map_photo_height[$i]);
		$stmt->bindValue(8, $map_photo_width[$i]);
		$stmt->bindValue(9, $map_place_id[$i]);
		$stmt->bindValue(10, $map_plus_comp_code[$i]);
		$stmt->bindValue(11, $map_plus_glob_code[$i]);
		$stmt->bindValue(12, $map_rating[$i]);
		$stmt->bindValue(13, $map_ref[$i]);
		$stmt->bindValue(14, $map_scope[$i]);
		$stmt->bindValue(15, $map_user_rat_total[$i]);
		$stmt->bindValue(16, $map_vicinity[$i]);


                                $stmt->execute();

		// クローズ
		$pdo = null;
		} catch (PDOException $e) {
		// 適宜エラー処理
		exit('データベース接続失敗。'.$e->getMessage());
		//exit($e->getMessage());
		}
			}
			}
			}
			}
			}
			}
			}
			}
			}
			}
			}
			}
			}
			}
			}
		}
	}
}

//sleep(3);
$str = $str + 1;

}
?>
