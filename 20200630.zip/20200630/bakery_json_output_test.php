<?php

// Google Places API を cURL でリクエスト
$baseUrl = "https://maps.googleapis.com/maps/api/place/nearbysearch/";
//$baseUrl = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=35.674914,139.762067&radius=500&types=bakery&language=ja&key=AIzaSyAIriIqW6ejAPWzDX3_1i4zTYwiF_btyUQ";
$fileType = "json";
$query    = [
          "location" =>  "35.674914,139.762067", // 東京の緯度経度
          "radius"   =>  1000, // 半径 500m
          "type"     =>  "bakery", // これは決められた範囲で選択可能
          "key"      =>  "AIzaXXXXXXXXXXXXXXXXXXXXXXXXXXX" // .envに書き込んだkeyをread
        ];

$query = http_build_query($query);
$url   = $baseUrl .$fileType.'?'.$query;


// fire
$curl = curl_init($url);
$options = [
          CURLOPT_HTTPGET => true,//GET
            CURLOPT_RETURNTRANSFER => true // fetch datum as strings
    ];

curl_setopt_array($curl, $options);
$result = curl_exec($curl);
curl_close ($curl);


// save datum

$fPath = "./";
$fName = "/tmp_bakeryyurakucho.json";
$file = fopen($fPath.$fName, "w+");// 上書き/新規作成
fputs($file, $result);
fclose($file);




$url = "https://sakura-web.tokyo/google_map/test_phase_3/tmp_bakeryyurakucho.json";
$json = file_get_contents($url);
$json = mb_convert_encoding($json, 'UTF8', 'ASCII,JIS,UTF-8,EUC-JP,SJIS-WIN');
$arr = json_decode($json,true);

$placesList = array();
  $nextPageToken = null;
  if ($arr["status"] == "OK"){
    //resultsをplacesList配列にマージ
    $placesList = array_merge($placesList, $arr["results"]);
    //next_page_tokenを取得
    $nextPageToken = $arr["next_page_token"];

} else if($placeData["status"] == "ZERO_RESULTS") {
    return "【Places API】検索結果が0件です。";
  } else if($placeData["status"] == "ERROR") {
    return "【Places API】サーバ接続に失敗しました。";
  } else if($placeData["status"] == "INVALID_REQUEST") {
    return "【Places API】リクエストが無効でした。";
  } else if($placeData["status"] == "OVER_QUERY_LIMIT") {
    return "【Places API】リクエストの利用制限回数を超えました。";
  } else if($placeData["status"] == "REQUEST_DENIED") {
    return "【Places API】サービスが使えない状態でした。";
  } else if($placeData["status"] == "UNKNOWN_ERROR") {
    return "【Places API】原因不明のエラーが発生しました。";
  }

         $str = "1";
 
//next_page_tokenが取得された場合は次ページあり。
//next_page_tokenが取得できなくなるまで、
//次ページ情報の取得を繰り返す。
while (empty($nextPageToken) == false){
	//2秒程間隔をおく（連続リクエストすると取得に失敗する）      
	sleep(2);
  
	// Google Places API を cURL でリクエスト
	$baseUrl = "https://maps.googleapis.com/maps/api/place/nearbysearch/";
	$fileType = "json";
	$query    = [
	          "key"      =>  "AIzaXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" // .envに書き込んだkeyをread
	        ];

	$query = http_build_query($query);
	$url   = $baseUrl .$fileType.'?'.$query.'&pagetoken='.$nextPageToken;

	// fire
	$curl = curl_init($url);
	$options = [
	          CURLOPT_HTTPGET => true,//GET
	            CURLOPT_RETURNTRANSFER => true // fetch datum as strings
	    ];

	curl_setopt_array($curl, $options);
	$result = curl_exec($curl);
	curl_close ($curl);

	// save datum
	//
 	$fPath = "./";
 	$fName = "/tmp_bakeryyurakucho".$str.".json";
 	$file = fopen($fPath.$fName, "w+");// 上書き/新規作成
 	fputs($file, $result);
 	fclose($file);
	//

	$url = "https://sakura-web.tokyo/google_map/test_phase_3/tmp_bakeryyurakucho".$str.".json";
	$json = file_get_contents($url);
	$json = mb_convert_encoding($json, 'UTF8', 'ASCII,JIS,UTF-8,EUC-JP,SJIS-WIN');
	$arr = json_decode($json,true);

	$placesList = array();
	$nextPageToken = null;

	echo "1";

	if ($arr["status"] == "OK"){
		//resultsをplacesList配列にマージ
		#$placesList = array_merge($placesList, $arr["results"]);
		$placesList = $arr["results"];

		//print_r $placesList;
		//exit;
		//next_page_tokenを取得
		$nextPageToken = $arr["next_page_token"];
	
		} else if($placeData["status"] == "ZERO_RESULTS") {
		return "【Places API】検索結果が0件です。";
		} else if($placeData["status"] == "ERROR") {
		return "【Places API】サーバ接続に失敗しました。";
		} else if($placeData["status"] == "INVALID_REQUEST") {
		return "【Places API】リクエストが無効でした。";
		} else if($placeData["status"] == "OVER_QUERY_LIMIT") {
		return "【Places API】リクエストの利用制限回数を超えました。";
		} else if($placeData["status"] == "REQUEST_DENIED") {
		return "【Places API】サービスが使えない状態でした。";
		} else if($placeData["status"] == "UNKNOWN_ERROR") {
		return "【Places API】原因不明のエラーが発生しました。";
		}
		  //                                                

		$placeJson = file_get_contents($url, false, $context);
		//JSON文字列をデコードして連想配列にする
		$placeData = json_decode($placeJson, true);
		
		if ($placeData["status"] == "OK"){
			echo "3";
			$str = $str + 1;
      			//resultsをplacesList配列にマージ
			$placesList = array_merge($placesList, $placeData["results"]);
      			//next_page_tokenを取得
			$nextPageToken = $placeData["next_page_token"];
		} else {
			$nextPageToken = null;
			echo "fin";
		}	    
	}
//}
//}
?>
